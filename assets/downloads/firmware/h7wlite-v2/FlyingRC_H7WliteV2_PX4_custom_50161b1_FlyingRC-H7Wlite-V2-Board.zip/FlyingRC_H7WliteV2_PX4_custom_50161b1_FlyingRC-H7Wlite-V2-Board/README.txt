FlyingRC H7Wlite V2 PX4 custom board-port build

Source branch: FlyingRC-H7Wlite-V2-Board
Base commit: 50161b1f09c31beade9a0bb5b4057276e9eac4ee
Board target: flyingrc_h7wlite-v2
Board ID: 1219
Compiler: Arm GNU Toolchain 10.2.1

Use flyingrc_h7wlite-v2_default.px4 as a custom firmware file in
QGroundControl. The bootloader and raw BIN files are included for recovery,
manufacturing, and advanced flashing workflows.

This is a custom board-port build, not an official tagged PX4 release.
Verify the H7Wlite V2 hardware revision before flashing.
