FlyingRC H7D Pro PX4 v1.17.0 firmware

Board target: flyingrc_h7dpro_default
Source: PX4 tag v1.17.0 + flyingrc/FlyingRC-H7D-Pro-Board board files
Compiler: arm-none-eabi-gcc 13.2.1
Build date: 2026-05-29

Files:
- flyingrc_h7dpro_default_px4-v1.17.0_FlyingRC-H7D-Pro-Board.px4
  Use this in QGroundControl custom firmware flashing.
- flyingrc_h7dpro_cubeprog_combined_0x08000000_px4-v1.17.0_FlyingRC-H7D-Pro-Board.bin
  STM32CubeProgrammer full image, flash start address 0x08000000.
- flyingrc_h7dpro_bootloader_0x08000000_px4-v1.17.0.bin
  Bootloader only, flash start address 0x08000000.
- flyingrc_h7dpro_app_0x08020000_px4-v1.17.0_FlyingRC-H7D-Pro-Board.bin
  PX4 app only, flash start address 0x08020000.

Notes:
- Only for FlyingRC H7D Pro hardware.
- Back up parameters before flashing.
- If flashing with STM32CubeProgrammer, use the combined image unless you specifically need separate bootloader/app flashing.
